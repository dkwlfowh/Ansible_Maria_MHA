#!/bin/sh
# master : 192.168.100.51
# slave : 192.168.100.52
# VIP network ens224
ssh root@192.168.100.51 sudo /sbin/ifdown eth1:1
ssh root@192.168.100.52 sudo /sbin/ifup eth1:1
